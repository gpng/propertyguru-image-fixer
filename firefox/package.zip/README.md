# PropertyGuru Image Fixer - Chrome Extension

PropertyGuru restricts their image heights to 360px after clicking on the image carousel, even on larger screen. This extension updates the images to fill up as much space as possible instead.

This extension simply injects some css.
